import UIKit


public func solution(_ A :[Int]) -> Int {
   //TODO: START IMPLEMENT HERE
    if A.count==3 {
        return A[0]*A[1]*A[2]
    }
    
    var sortA = A
    sortA.sort()
    var casenegative=0
    if (sortA[0]<0) && (sortA[1]<0) {
        casenegative = sortA[0]*sortA[1]
    }
    if casenegative != 0 {
        return max(casenegative*sortA[sortA.count-1], sortA[sortA.count-1]*sortA[sortA.count-2]*sortA[sortA.count-3])
    }
    return sortA[sortA.count-1]*sortA[sortA.count-2]*sortA[sortA.count-3]

}

//print(solution([-6,2,4,-5,10,12]))
print(solution([-6,-2,0,12]))
print(solution([-16,-2,0,12]))
